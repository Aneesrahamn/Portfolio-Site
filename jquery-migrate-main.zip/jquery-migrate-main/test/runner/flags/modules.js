export const modules = [
	"migrate",
	"core",
	"ajax",
	"attributes",
	"css",
	"data",
	"effects",
	"event",
	"manipulation",
	"offset",
	"serialize",
	"traversing",
	"deferred"
];
